@echo off
.\gradlew wrapper
